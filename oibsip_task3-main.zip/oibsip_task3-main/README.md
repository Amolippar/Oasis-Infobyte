# oibsip_task3
## ATM Interface
We have all come across ATMs in our cities and it is built on Java. This complex project consists of
five different classes and is a console-based application. When the system starts the user is
prompted with user id and user pin. On entering the details successfully, then ATM functionalities
are unlocked. The project allows to perform following operations:

1)Transactions History
2)Withdraw
3)Deposit
4)Transfer
5)Quit


https://user-images.githubusercontent.com/85325733/204094354-cf407487-16e6-4740-8359-df07a40b5446.mp4

